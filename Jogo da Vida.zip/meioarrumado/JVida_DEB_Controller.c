// Jogo Da vida
// Discipulos de Eli Banks(DEB)
// Nome dos integrantes:
// Pedro Marques Prado  || Giovana Akemi Maeda Mathias || Lucas Kenji Hayashi || Ricardo Lins Pires
// Arquivo CONTROLLER.C



#include "JVida_DEB_Controller.h"
#include "JVida_DEB_Model.h"



void CriarMatriz() {

	int OK = 1;
	do {



		Mensagens(1);
		scanf("%d", &Compr);



		if ((Compr < MIN) || (Compr > MAX)) {
			Mensagens(2);
			OK = 0;
		} else
			OK = 1;


	} while (OK == 0);
	Compr++;
	Mensagens(3);
	// bota '.' em tds os lugares da matriz
	for (i = 1; i < Compr; i++) {
		for (j = 1; j < Compr; j++) {
			Matriz[i][j] = MORTO;
		}
	}




}



void ApresentaMatriz() {
	//imprime a matriz

	mostraLvivo();

	Mensagens(6);


	for(i=1; i<Compr; i++) {
		Mensagens(7);
	}
	Mensagens(3);

	for(i=1; i<Compr; i++) {
		Mensagens(13);
		for(j=1; j<Compr; j++) {
			if(Matriz[i][j] == '+')
				printf(".   ");
			else
				Mensagens(8);
		}

		Mensagens(3);
	}
}
// oi



void ExecutarMenu() {

	do {
		OP = ApresentaMenu();
		switch (OP) {
			case 1:
				ApresentaMatriz();
				break;
			case 2:
				carregaVivo();
				break;
			case 3:
				Simulacao();
			case 4:
				ListaCelulas();
				break;
			case 5:
				mostraLmorto();
				break;
			case 6:
				gravaCelulas();
				break;
			case 7:
				recuperaCelulas();
				break;
			case 0:
				break;
			default:
				Mensagens(9);
				break;
		}
	} while (OP != 0);
}



void carregaVivo() {
	if(carrega == 0)
	{
	
	do {
		excluir = 0;
		
		//alocacaoo dinamica
		ApresentaMatriz();
		Mensagens(5);
		scanf("%d,%d", &ii, &jj);
		if(ii != -1) {
			cVivoaux = malloc(sizeof(TipoCelula));
			if (cVivoaux == NULL) {
				Mensagens(4);
				return;
			}
		}
		if((ii < Compr) && (ii > 0) && (jj < Compr) && (jj > 0)) {

			excluiLVivo();

			//sempre inclui no inicio da listaporque neste caso a ordem nao importa
			if((ii != -1) && (excluir == 0) && (jj != -1))  {
				//carrega os dados da celula:  ii e jj
				cVivoaux->linha = ii;
				cVivoaux->coluna = jj;


				if(totvivo== 0) { //se a lista esta vazia
					pvivo = cVivoaux;
					pvivo->next = NULL;
					Matriz[pvivo->linha][pvivo->coluna] = VIVO;

				} else {            //lista nao vazia
					cVivoaux->next = pvivo;
					pvivo = cVivoaux;  //o inicio da lista passa a ser a nova celula

				}
				totvivo++;
				
			}

		} else
			Mensagens(10);
	} while(ii != -1);
	}
	if(carrega == 1)
		{
		cVivoaux = malloc(sizeof(TipoCelula));
		printf("foicarregavivocarrega=1\n");
				cVivoaux->linha = ii;
				cVivoaux->coluna = jj;


				if(totvivo	== 0) { //se a lista esta vazia
					pvivo = cVivoaux;
					pvivo->next = NULL;
					Matriz[pvivo->linha][pvivo->coluna] = VIVO;
					printf("carregoucelulaprimeira\n");
				} else {            //lista nao vazia
					cVivoaux->next = pvivo;
					pvivo = cVivoaux;  //o inicio da lista passa a ser a nova celula
					printf("carregou celula proxima\n");
				}
				totvivo++;
					
		}
carregaMortosVizinhos();
}



//Exclui uma celula viva da lista LVivo
void excluiLVivo() {

	TipoCelula *aux, *aux2;
	aux = pvivo;
	aux2 = aux;
	if (totvivo > 0) {
		while (aux->linha != ii || aux->coluna != jj) {
			aux2 = aux;
			if(aux->next == NULL)
				break;
			aux = aux->next;
		}
		if (aux->linha == ii && aux->coluna == jj) {
			Mensagens(11);
			scanf("%d",&excluir);
			if(excluir == 1) {
				ReiniciarLMortos();
				if (aux2 == aux)   //o o primeiro da lista
					pvivo = aux->next;
				else
					aux2->next = aux->next;
				free(aux);
				Matriz[ii][jj] = MORTO;
				Mensagens(12);
				totvivo = totvivo - 1;
				if(totvivo > 0)
					carregaMortosVizinhos();
			}
		}

	}
}



//apresenta todas as celulas vivas
void mostraLvivo() {
	int a,b;
	TipoCelula *aux;
	//define um ponteiro auxiliar
	aux = pvivo;
	//inicializa esse ponteiro auxiliar
	if (totvivo > 0) {

		while((aux->next != NULL) ) {
			a = aux->linha;
			b = aux->coluna;
			Matriz[a][b] = VIVO;
			aux = aux->next;
			//caminha para o proximo ponteiro
		}
		printf("%d,%d  \n ", aux->linha, aux->coluna);
		Matriz[aux->linha][aux->coluna] = VIVO;
		//mostra a ultima celula
	}

	Mensagens(3);
}



void Simulacao() {
/*
1. Qualquer celula viva com menos de dois vizinhos vivos morre de solidao.
2. Qualquer celula viva com mais de tres vizinhos vivos morre de superpopulacao.
3. Qualquer celula com exatamente tres vizinhos vivos se torna uma celula viva.
4. Qualquer celula com dois vizinhos vivos continua no mesmo estado para a proxima geracao.
*/
	int opcao;
	if(pvivo == NULL)
		return;	
	printf("Quantas geracoes quer passar ? (1 a 10): ");
	scanf("%d",&opcao);
	if((opcao < 1) || (opcao > 10))
		{
		printf("Erro,escolha uma opcao valida ao iniciar a simulacao\n");
		return;
		}
	printf("1 passo\n");	
	TipoCelula *auxmorto;
	printf("2 passo\n");
	pvivoprox = pvivo;
	printf("3 passo\n");
	auxprox = pvivoprox;
	printf("4 passo\n");
	for(i = 0;i < opcao;i++)
	{
	printf("5 passo\n");
	totvivoprox = 0;
	selectlist = 1;
	
	while(auxprox->next != NULL)
		{
		printf("6 passo\n");
		verificacoesSimulacaoVivos();
		destinoCelula();
		if(auxprox->next != NULL)
			auxprox = auxprox->next;
		totvivoprox = 0;				
		}
		verificacoesSimulacaoVivos();
		destinoCelula();
		totvivoprox = 0;
	
	auxprox = pmorto;
	selectlist = 0;
	
	while(auxprox->next != NULL)
		{
		verificacoesSimulacaoVivos();
		destinoCelula();
		if(auxprox->next != NULL)
			auxprox = auxprox->next;
		totvivoprox = 0;				
		}
		verificacoesSimulacaoVivos();
		destinoCelula();
		totvivoprox = 0;
		
	pvivo = pvivoprox;
	}
	carregaMortosVizinhos();
}
void verificacoesSimulacaoVivos()
{
	printf("7 passo\n");
	aux2 = auxprox;
	ii = aux2->linha;
	jj = aux2->coluna; 
	//bota 'aux2' na posicao cima esq do vivo
		aux2->linha = ii - 1;						
		aux2->coluna = jj - 1;
		printf("8 passo\n");
		verificaVivosim();
		
		aux2->linha = ii - 1;
		aux2->coluna = jj;
		verificaVivosim();
		
		aux2->linha = ii - 1;
		aux2->coluna = jj + 1;
		verificaVivosim();
		
		aux2->linha = ii;
		aux2->coluna = jj - 1;
		verificaVivosim();
		
		aux2->linha = ii;
		aux2->coluna = jj + 1;
		verificaVivosim();
		
		aux2->linha = ii + 1;
		aux2->coluna = jj - 1;
		verificaVivosim();
		
		aux2->linha = ii + 1;
		aux2->coluna = jj;
		verificaVivosim();		
		
		aux2->linha = ii + 1;
		aux2->coluna = jj + 1;
		verificaVivosim();
			
}
void verificaVivosim()
{
	TipoCelula *aux3;
	aux3 = auxprox;
	printf("9 passo\n");
	while(aux3->next != NULL)
		{
		printf("10 passo\n");
		if((aux3->linha == aux2->linha) && (aux3->coluna == aux2->coluna))
			{
			totvivoprox = totvivoprox + 1;	
			}
		aux3 = aux3->next;
		}
		if((aux3->linha == aux2->linha) && (aux3->coluna == aux2->coluna))
			{
			totvivoprox = totvivoprox + 1;	
			}
}
void destinoCelula()
{
	//1 para lista de vivos e 2 para lista de mortos
	if(selectlist = 1)
	{
		
	
	if((totvivoprox < 2) || (totvivoprox > 3))
		{
		
		TipoCelula *Morte, *ajudanteMorte;
		Morte = pvivo;
		ajudanteMorte = Morte;
		
		while((Morte->linha != auxprox->linha) && (Morte->coluna != auxprox->coluna))
			{
				ajudanteMorte = Morte;
				Morte = Morte->next;
			}
		
		if(Morte == ajudanteMorte)
			auxprox = auxprox->next;
		else
			ajudanteMorte->next = Morte->next;	
				
		}
	}
	if(selectlist = 0)
		{
			
		
		}	
}
void verificacoesSimulacaoMortos()
	{
		
	}
void ReiniciarLMortos() {
	if(pmorto == NULL)
		return;
	
	TipoCelula *Rmorto;
	int Sentinela = 0;
	Rmorto = pmorto;
	while(Rmorto->next != NULL)
		Rmorto = Rmorto->next;		
	pmorto = Rmorto->next;
	totmorto = 0;
	for (i = 1; i < Compr; i++) {
		for (j = 1; j < Compr; j++) {
			Matriz[i][j] = MORTO;
		}
	}
		//caminha para o proximo ponteiro
}

// bota como 'MORTO' tudo ao redor dos vivos
void carregaMortosVizinhos() {

	int OK;
	TipoCelula *aux;
	ReiniciarLMortos();
	aux = pvivo;
	ii = aux->linha;
	jj = aux->coluna;

	// Repete para cada ser vivo
	do {
		printf("foi o do carrega vizinho\n");
		ii = aux->linha;
		jj = aux->coluna;

		// ========================================= CIMA ESQ =========================================
			aux2 = malloc(sizeof(TipoCelula));
			
			//bota 'aux2' na posicao cima esq do vivo
			aux2->linha = ii - 1;						
			aux2->coluna = jj - 1;
			
			lin = aux2->linha;
			col = aux2->coluna;
			printf("LINHA %d\tCOLUNA %d\n",lin,col);
			carregaMortosVizinhos2();
			
		// ========================================= CIMA =========================================
			aux2 = malloc(sizeof(TipoCelula));
			
			//bota 'aux2' na posicao cima do vivo
			aux2->linha = ii - 1;
			aux2->coluna = jj;
			
			lin = aux2->linha;
			col = aux2->coluna;
			printf("LINHA %d\tCOLUNA %d\n",lin,col);
			carregaMortosVizinhos2();
			
		// ========================================= CIMA DIR =========================================
			aux2 = malloc(sizeof(TipoCelula));
			
			//bota 'aux2' na posicao cima dir do vivo
			aux2->linha = ii - 1;
			aux2->coluna = jj + 1;
			
			lin = aux2->linha;
			col = aux2->coluna;
			printf("LINHA %d\tCOLUNA %d\n",lin,col);
			carregaMortosVizinhos2();
		
		// ========================================= ESQ =========================================
			aux2 = malloc(sizeof(TipoCelula));
			
			//bota 'aux2' na posicao esq do vivo
			aux2->linha = ii;
			aux2->coluna = jj - 1;
			
			lin = aux2->linha;
			col = aux2->coluna;
			printf("LINHA %d\tCOLUNA %d\n",lin,col);
			carregaMortosVizinhos2();
		
		// ========================================= DIR =========================================
			aux2 = malloc(sizeof(TipoCelula));
			
			//bota 'aux2' na posicao dir do vivo
			aux2->linha = ii;
			aux2->coluna = jj + 1;
			
			lin = aux2->linha;
			col = aux2->coluna;
			printf("LINHA %d\tCOLUNA %d\n",lin,col);
			carregaMortosVizinhos2();
			
		// ========================================= BAIXO ESQ =========================================
			aux2 = malloc(sizeof(TipoCelula));
			
			//bota 'aux2' na posicao baixo esq do vivo
			aux2->linha = ii + 1;
			aux2->coluna = jj - 1;
			lin = aux2->linha;
			col = aux2->coluna;
			printf("LINHA %d\tCOLUNA %d\n",lin,col);
			carregaMortosVizinhos2();
			
		// ========================================= BAIXO =========================================
			aux2 = malloc(sizeof(TipoCelula));
			
			//bota 'aux2' na posicao baixo do vivo
			aux2->linha = ii + 1;
			aux2->coluna = jj;
			
			lin = aux2->linha;
			col = aux2->coluna;
			printf("LINHA %d\tCOLUNA %d\n",lin,col);
			carregaMortosVizinhos2();
			
		// ========================================= BAIXO DIREITA =========================================
			aux2 = malloc(sizeof(TipoCelula));
			
			//bota 'aux2' na posicao baixo dir do vivo
			aux2->linha = ii + 1;
			aux2->coluna = jj + 1;
			
			lin = aux2->linha;
			col = aux2->coluna;
			printf("LINHA %d\tCOLUNA %d\n",lin,col);
			carregaMortosVizinhos2();
			
		// ========================================= ============= =========================================
		
		// Caso NAO tenha um prox elemento na lista de vivos
		if(aux->next == NULL)
			// Para tudo
			OK = 1;
		
		//  Caso tenha 
		else
			// Passa tudo pro prox ser vivo
			aux = aux->next;
			
	} while (OK == 0);
		printf("TOTAL DE MORTOS: %d\n",totmorto);

}

// Verifica as condicoes pra poder colocar MORTO
// Caso seja verdadeiro, 'Verificar = 1'
void Verifica1Morto() {
	int OK2;
	TipoCelula *Mortoaux, *auxverificavivo;
	Mortoaux = pmorto;
	auxverificavivo = pvivo;
	Verificar = 0;
	OK2 = 0;
	
	
	if((lin >= Compr)||(lin < 1) || (col >= Compr) || (col < 1)) {
		Verificar = 1;
		printf("Celula morta em posicao nao devida\n");
		return;
	}
	else if(Matriz[lin][col] == VIVO)
		{
		Verificar = 1;
		printf("Celula morta em posicao nao devida\n");
		return;
		}
	else if(Mortoaux != NULL) {

		do {
			if((Mortoaux->linha == lin) && (Mortoaux->coluna == col)) {
				OK2 = 1;
				Verificar = 1;
			}  
			else if(Mortoaux->next != NULL)
				Mortoaux = Mortoaux->next;
			else
				OK2 = 1;
		} while(OK2 == 0);
		
		while(auxverificavivo->next != NULL)
			{
			if((auxverificavivo->linha == lin) && (auxverificavivo->coluna == col))
				{
				Verificar = 1;
				return;
				}	
			auxverificavivo = auxverificavivo->next;
			}
		
		if(Verificar == 0) {
			totmorto = totmorto + 1;
		}
	}
printf("VERIFICAR = %d\n",Verificar);
}

// continuacao do void 'carregaMortosVizinhos'
void carregaMortosVizinhos2 () {
	
	// Verifica as condicoes pra colocar morto
	Verifica1Morto();
			
	// Se lista vazia
	if (totmorto == 0){
		
		// Caso as condicoes sejam atendidas
		if(Verificar == 0) {
			// 'pmorto' copia a posicao de 'aux2'
			pmorto = aux2;
			printf("Deu certo verificacao, adicionou totmorto = 0\n");
			// anula a posicao do prox elemento da matriz de 'pmorto'
			pmorto->next = NULL;
			
			// bota na posicao de 'pmorto' como 'MORTOPROX'
			Matriz[pmorto->linha][pmorto->coluna] = MORTOPROX;
		}
	}
			
	// Se listao NAO vazia
	else {
		// Caso as condicoes sejam atendidas
		if(Verificar == 0) {
			printf("Deu certo verificacao, adicionou totmorto > 0\n");	
			// bota o prox elemento da matriz 'aux2' na posicao do 'pmorto'
			aux2->next = pmorto;
					
			// 'pmorto' copia a posicao de 'aux2'
			pmorto = aux2;
		}
		
		// bota na posicao de 'pmorto' como 'MORTOPROX'
		Matriz[pmorto->linha][pmorto->coluna] = MORTOPROX;
	}
	
}

void ListaCelulas() {
	if(pvivo == NULL) {
		Mensagens(14);
		return;
	}
	int Flista1 = 0;
	int Flista2 = 0;
	int a,b;
	TipoCelula *aux;
	TipoCelula *auxaplista;
	Mensagens(15);
	aux = pvivo;
	auxaplista = pmorto;
	do {
		printf("%d,%d\t",aux->linha,aux->coluna);
		if(aux->next == NULL)
			Flista1 = 1;
		else
			aux = aux->next;
	} while(Flista1 == 0);
	Mensagens(3);
	Mensagens(16);
	while((auxaplista->next != NULL) ) {
		a = auxaplista->linha;
		b = auxaplista->coluna;
		printf("%d,%d\t",auxaplista->linha,auxaplista->coluna);
		auxaplista = auxaplista->next;
		//caminha para o proximo ponteiro
	}
	printf("%d,%d   ",auxaplista->linha,auxaplista->coluna);
	Mensagens(3);
}
void mostraLmorto() {
	mostraLvivo();

	Mensagens(6);


	for(i=1; i<Compr; i++) {
		Mensagens(7);
	}
	Mensagens(3);

	for(i=1; i<Compr; i++) {
		Mensagens(13);
		for(j=1; j<Compr; j++) {
			Mensagens(8);
		}

		Mensagens(3);
	}


}

void gravaCelulas() {
	i = 0;
	TipoCelula *auxg;
	auxg = pvivo;
	int totvivoaux = totvivo;
	
	FILE *fp;
		if ((fp = fopen("CONFIG_INIC", "w")) == NULL) {
			Mensagens(17);
			printf("GRAVA CONFIG INIC\n");
			exit(0);
		}
		
	printf("GRAVA antes de tudo\n");
	do {
		
		LConfig[i].linha = auxg->linha;
		LConfig[i].coluna = auxg->coluna;
		printf("%d||%d\n",LConfig[i].linha,LConfig[i].coluna);
		
		printf("GRAVA do inicio\n ");

		if(fwrite(&LConfig[i], sizeof(TipoCelula), 1, fp)  != 1) {
			Mensagens(18);
			printf("GRAVA CONFIG WRITE\n");
			break;
		}
		auxg = auxg->next;
		i++;
	printf("%d\n",totvivoaux);
	totvivoaux = totvivoaux - 1;	
	
	} while(totvivoaux != 0);
		LConfig[i].next = NULL;
	 	
	 if(LConfig[i].next == NULL)
	 	printf("pai ta NULL\n");
	 fclose(fp);
	printf("GRAVA cabo o do\n");

	if((fp = fopen("totalvivo","w")) == NULL)
		{
		printf("O arquivo totalvivo nao pode ser aberto para gravacao\n");
		exit(0);	
		}
	if(fwrite(&totvivo,sizeof(int),1,fp) != 1)
		{
		printf("Erro na gravacao do arquivo totvivo");	
		}
	fclose(fp);
	printf("GRAVA cabo\n");
}

void recuperaCelulas() {
	i = 0;
	FILE *fp;
	
	printf("");
	if ((fp = fopen("totalvivo", "r")) == NULL) {
			Mensagens(23);
			printf("RECUPERA CONFIG INIC OPNE\n");
			exit(0);
		}
	if(fread(&totvivo, sizeof(int), 1, fp)  != 1) {
			Mensagens(24);
			printf("RECUPERA totvivo\n");
			return;
		}
	int totvivoaux = totvivo;
	fclose(fp);
	totvivo = 0;		
	fp = fopen("CONFIG_INIC", "r");
	if ((fp = fopen("CONFIG_INIC", "r")) == NULL) {
			Mensagens(23);
			printf("RECUPERA CONFIG INIC OPNE\n");
			exit(0);
		}
		
		carrega = 1;
	if(LConfig[i].next == NULL)
	 	printf("pai ta NULLWTF\n");
	do 
	{
		
		
		printf("RECUPERA dentro do do\n");

		if(fread(&LConfig[i], sizeof(TipoCelula), 1, fp)  != 1) {
			Mensagens(24);
			printf("RECUPERA CONFIG READ\n");
			break;
		}
		printf("fora do do\n");
		printf("%d||%d\n",LConfig[i].linha,LConfig[i].coluna);
		ii = LConfig[i].linha;
		jj = LConfig[i].coluna;
		printf("passou o do\n");
		carregaVivo();
		printf("TOTVIVOAUX = %d\n",totvivoaux);
		totvivoaux = totvivoaux - 1;
		i++;
	} while(totvivoaux != 0);
	
	
	printf("%d||%d ii = %d jj = %d\n",LConfig[i].linha,LConfig[i].coluna,ii,jj);
	fclose(fp);
	carregaMortosVizinhos();
	printf("FORA DO WHILE\n");
	printf(" aq ctz q nao vai\n");
	carrega = 0;
}
