//Jogo Da vida 
//Discipulos de Eli Banks(DEB)
//Nome dos integrantes: 
//Pedro Marques Prado  || Giovana Akemi Maeda Mathias || Lucas Kenji Hayashi || Ricardo Lins Pires
//Arquivo VIEW.CPP
#include "JVida_DEB_View.h"
#include "JVida_DEB_Model.h"
int ApresentaMenu(){
	int OP;
	
	printf("[1]: Apresenta Matriz\n");
	printf("[2]: Colocar celulas\n");
	printf("[3]: Iniciar Simulacao\n");
	printf("[4]: Mostrar lista de celulas\n");
	printf("[5]: Mostrar Celulas mortas\n");
	printf("[6]: Salvar celulas\n");
	printf("[7]: Recuperar celulas\n");
	printf("[0]: Sair");
	
	
	printf("\nEscolha uma das opcoes acima: ");
	scanf("%d", &OP);
	
	return OP;
	
}

int Mensagens(int mensagem){
	
	switch(mensagem){
		case 1:
			printf("Defina o tamanho do mundo (de 10 a 60): ");
			break;
		case 2:
			printf("Erro, escolha um numero entre 10 e 60\n");
			break;
		case 3:
			printf("\n");
			break;
		case 4:
			printf("Sem espaco na memoria para inclusao de celula viva\n");
			break;
		case 5:
			printf("Digite a posicao da celula(x,y)(-1 para sair): ");
			break;
		case 6:
			printf("     ");
			break;
		case 7:
			printf("%.2d  ", i);
			break;
		case 8:
			printf("%.2c   ", Matriz[i][j]);
			break;
		case 9:
			printf("\nERRO: Escolha uma opcao valida do menu.\n\n");
			break;
		case 10:
			printf("\n\nERRO: Escolha uma posicao valida para a celula ou -1 para sair\n");
			break;
		case 11:
			printf("\nEsse espaco ja e ocupado por uma celula,deseja remove - la?(1)Sim\t(2)Nao: ");
			break;
		case 12:
			printf("\nCelula removida!\n");
			break;
		case 13:
			printf("%.2d    ", i);
			break;
		case 14:
			printf("\nLista Vazia\n");
			break;
		case 15:
			printf("\nLista de coordenadas das celulas vivas: ");	
			break;
		case 16:
			printf("\nLista de coordenadas das celulas Mortas: ");
			break;
		case 17:
			printf("O arquivo CONFIG_INIC nao pode ser aberto para gravacao\n");
			break;
		case 18:
			printf("Erro na gravacao do arquivo CONFIG_INIC\n");
			break;
		case 19:
			printf("O arquivo salvaVivo nao pode ser aberto para gravacao\n");
			break;
		case 20:
			printf("Erro na gravacao do arquivo salvaVivo\n");
			break;
		case 21:
			printf("O arquivo salvaVivo nao pode ser aberto para leitura\n");
			break;
		case 22:
			printf("Erro na gravacao do arquivo leitura\n");
			break;
		case 23:
			printf("O arquivo CONFIG_INIC nao pode ser aberto para leitura\n");
			break;
		case 24:
			printf("Erro na leitura do arquivo CONFIG_INIC\n");
			break;
	}
	return mensagem;
	
}
