//Jogo Da vida
//Discipulos de Eli Banks(DEB)
//Nome dos integrantes:
//Pedro Marques Prado  || Giovana Akemi Maeda Mathias || Lucas Kenji Hayashi || Ricardo Lins Pires
//Arquivo MODEL.H
#include<stdio.h>
#include<stdlib.h>
#define MAX 60 //tamanho maximo da matriz
#define MIN 10 //tamanho minimo da matriz
#define VIVO 'O'
#define MORTO '.'
#define MORTOPROX '+'




typedef struct cel
        {
        int linha,coluna;
        struct cel *next;    
        } TipoCelula;



//ponteiros do inicio de cada lista
TipoCelula *pvivo, *pmorto, *pvivoprox;
TipoCelula *cVivoaux, *auxprox;
TipoCelula LConfig[100];
int totvivo, totmorto, totvivoprox;   //totais das listas
char Matriz[61][61];
int Compr,i,j,OP;
int ii,jj,lin,col;
int excluir;
int Verificar;
int salvaVivo;
int carrega;
int selectlist;


TipoCelula *aux2;
