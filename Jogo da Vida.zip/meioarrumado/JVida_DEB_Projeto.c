//Jogo Da vida 
//Discipulos de Eli Banks(DEB)
//Nome dos integrantes: 
//Pedro Marques Prado  || Giovana Akemi Maeda Mathias || Lucas Kenji Hayashi || Ricardo Lins Pires
//Arquivo PROJETO.CPP ou MAIN

main()
{
	CriarMatriz();	
	ExecutarMenu();
}
