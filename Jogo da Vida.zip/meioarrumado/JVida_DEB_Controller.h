//Jogo Da vida
//Discipulos de Eli Banks(DEB)
//Nome dos integrantes:
//Pedro Marques Prado  || Giovana Akemi Maeda Mathias || Lucas Kenji Hayashi || Ricardo Lins Pires
//Arquivo CONTROLLER.H


void Verifica1Morto();
void CriarMatriz();
void ApresentaMatriz();
void ExecutarMenu();
void ReiniciarLMortos();
void carregaVivo();
void Simulacao();
void mostraLvivo();
void ReiniciaMatriz();
void excluiLVivo();
void carregaMortosVizinhos();
void carregaMortosVizinhos2();
void ListaCelulas();
void mostraLmorto();
void gravaCelulas();
void recuperaCelulas();
void verificacoesSimulacaoVivos();
void verificacoesSimulacaoMortos();
void verificaVivosim();
void destinoCelula();
